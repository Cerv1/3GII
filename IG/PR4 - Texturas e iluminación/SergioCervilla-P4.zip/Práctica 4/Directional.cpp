#include "Directional.h"

Directional::Directional(){
    alpha=0;
    beta=0;

    const float
    caf[4] = { 0.0, 0.0, 0.0, 1.0 },          // color ambiental de la fuente
    cdf[4] = { 1.0, 1.0, 1.0, 1.0 },         // color difuso de la fuente
    csf[4] = { 1.0, 1.0, 1.0, 1.0 };           // color especular de la fuente
    glLightfv( GL_LIGHT1, GL_AMBIENT, caf );
    glLightfv( GL_LIGHT1, GL_DIFFUSE, cdf );
    glLightfv( GL_LIGHT1, GL_SPECULAR, csf );

    const GLfloat dirf[4] = { 0, 250, 0, 0.0 } ; // (x,y,z,w)
    glLightfv( GL_LIGHT1, GL_POSITION, dirf );
}

void Directional::enable(){
    glEnable(GL_LIGHTING);
    GLfloat light1_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
    GLfloat light1_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light1_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light1_position[] = { -2.0, 2.0, 1.0, 1.0 };
    GLfloat spot_direction[] = { -1.0, -1.0, 0.0 };
    glLightfv(GL_LIGHT1, GL_AMBIENT, light1_ambient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse);
    glLightfv(GL_LIGHT1, GL_SPECULAR, light1_specular);
    glRotatef( alpha, 0.0, 1.0, 0.0 ) ;
    glRotatef( beta, -1.0, 0.0, 0.0 ) ;
    glEnable(GL_LIGHT1);
}

void Directional::disable(){
  glDisable(GL_LIGHT1);
}

void Directional::move_light(float position){
  GLfloat light_position[] = { position*2/3, 100.0, 0.0, 0.0 };
  glLightfv(GL_LIGHT1, GL_POSITION, light_position);
}

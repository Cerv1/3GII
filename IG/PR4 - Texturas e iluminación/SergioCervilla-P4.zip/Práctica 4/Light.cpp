#include "Light.h"

Light::Light(){
    color.assign(3,0.0);
}
